(function(){
  if(location.search.indexOf('success') !== -1){
    alert('Thank you — your appointment request was submitted. We will contact you soon.');
  }
})();
