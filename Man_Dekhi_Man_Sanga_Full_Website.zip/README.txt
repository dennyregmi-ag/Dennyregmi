Man Dekhi Man Sanga - Professional Website (Netlify-ready)
---------------------------------------------------------

Included files:
- index.html (Home)
- about.html (About Deni Regmi)
- services.html (Services)
- contact.html (Contact + Netlify form)
- styles.css (site styles)
- script.js (small enhancements)
- images/profile.jpg (your uploaded photo)

Deploying on Netlify:
1. Unzip the folder.
2. Go to https://app.netlify.com -> Add new site -> Deploy manually -> Drag & drop the unzipped folder.
3. After deploy, go to Site settings -> Domain management -> Add custom domain (dennyregmi.com.np).
4. Update DNS at register.com.np to point to Netlify (A record or CNAME).

Netlify forms:
- The contact form uses Netlify Forms (data-netlify="true"). Submissions appear in your Netlify dashboard.
- To receive email notifications to dennyregmi@gmail.com, enable Notifications in Netlify Site -> Forms settings and add your email.

Replace any copy, times, or details as needed.
